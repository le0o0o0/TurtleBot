import os
import select
import sys
import rclpy
import numpy


from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist, PoseStamped
from rclpy.qos import QoSProfile
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan
from nav2_simple_commander.robot_navigator import BasicNavigator
from nav_msgs.msg import Odometry
#from nav2_simple_commander.action import TaskResult
import math
import time

if os.name == 'nt':
    import msvcrt
else:
    import termios
    import tty

class SharedData():
    def __init__(self):
        self.init_x = 0.0
        self.init_y = 0.0
        self.rot_w = 0.0

sharedData = SharedData()

class MinimalSubscriber(Node):
    def __init__(self):
        super().__init__('minimal_subscriber')
        qos = QoSProfile(depth=10)
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10)
        
        self.subscription = self.create_subscription(
            LaserScan,
            'scan',
            self.listener_callback,
            #10) #self.listener_callback, 10) -> for simulation
            qos_profile, #for the real robot
        )
        self.subscription  # prevent unused variable warning
        self.pub = self.create_publisher(Twist, 'cmd_vel', qos)
        self.pub_end = self.create_publisher(String, 'follow_me_finish', qos)
        self.immobility_value = 0.1
        self.t0 = time.time()
        self.is_finish = False
        self.is_moving = False

    def listener_callback(self, msg):
        #FILTER ALGO
        angles = [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 359, 358, 357, 356, 355, 354, 353, 352, 351, 350, 349, 348, 347, 346, 345, 344, 343, 342, 341, 340]
        len_angles = len(angles)
        print(f"Angles tab lengh : {len_angles}")
        ranges = msg.ranges[0:20] #first array
        ranges_2 = msg.ranges[-21:-1] #second array
        #fuse both arrays clockwise, turns it into a tab
        tab_ranges = []
        i = 0
        j = 0
        while i < 20:
            k = (i*-1) - 1
            rounding_1 = round(ranges[k],2)
            tab_ranges.append(ranges[k])
            i += 1
        while j < 20:
            l = (j*-1) - 1
            rounding_2 = round(ranges_2[l],2)
            tab_ranges.append(ranges_2[l])
            j += 1

        # Check if tab_ranges is at the correct lengh
        # print(len(tab_ranges)) <- this was confirmed to be working

        # Delete 'inf' values
        inf_index = 0
        tab_without_inf = []
        angles_without_inf = []
        while inf_index < len(tab_ranges):
            if tab_ranges[inf_index] == math.inf:
                #do nothing
                inf_index += 0
            elif inf_index == len(tab_ranges):
                #how
                inf_index += 0
            else:
                tab_without_inf.append(tab_ranges[inf_index])
                angles_without_inf.append(angles[inf_index])
            inf_index += 1
        
        # Delete x<2 and 3>x distance values
        min_range = 0.5
        max_range = 2
        index = 0
        final_tab = []
        final_angles = []
        while index < len(tab_without_inf):
            if tab_without_inf[index] < min_range or tab_without_inf[index] > max_range:
                index += 0
            else:
                # Valeur est incluse dans notre fouchette
                final_tab.append(tab_without_inf[index])
                final_angles.append(angles_without_inf[index])
            index += 1

        # Calculate average distance & angle
        average_distance = 0
        average_angle = 0
        avr_counter_1 = 0
        avr_counter_2 = 0
        konstante_1 = 0
        konstante_2 = 0
        if len(final_tab) == 0:
            print("Cannot do an average of distance (No data)") #because dividing by zero is a bad idea
        else:
            while avr_counter_1 <= len(final_tab):
                if avr_counter_1 < len(final_tab):
                    konstante_1 += final_tab[avr_counter_1]
                elif avr_counter_1 == len(final_tab):
                    average_distance = konstante_1 / len(final_tab) #<- case in point
                else:
                    # h o w
                    avr_counter_1 += 0
                avr_counter_1 += 1
        if len(final_angles) == 0:
            print("Cannot do an average of angles (No data)")
        else:
            while avr_counter_2 <= len(final_angles):
                if avr_counter_2 < len(final_angles):
                    #we turn [340:359] values into [-20:-1]
                    if final_angles[avr_counter_2] > 339:
                        konstante_2 += (final_angles[avr_counter_2] - 360)
                    else:
                        konstante_2 += final_angles[avr_counter_2]
                elif avr_counter_2 == len(final_angles):
                    average_angle = konstante_2 / len(final_angles)
                else:
                    # h o w
                    avr_counter_2 += 0
                avr_counter_2 += 1

        # We now know where to go, now we just need to get to it
        # en fonction de center_point_distance/center_point_angle et average_distance/average_angle
        # faire déplacer le robot avec Twist
        twist_move = Twist()
        # DEFINING CENTER OF OUR "AREA"
        center_point_distance = (max_range + min_range) * 0.5
        if len(final_tab) == 0:
            twist_move.linear.x = 0.0
        else:
            if average_distance > 1.25: #between 1 and 2m
                twist_move.linear.x = (average_distance - center_point_distance) * 1.0 #-1.25 when average_distance does not have any data
            else: #between 2 and 3m
                twist_move.linear.x = (average_distance - center_point_distance) * 0.75 #-1.25 when average_distance does not have any data
        twist_move.linear.y = 0.0
        twist_move.linear.z = 0.0

        twist_move.angular.x = 0.0
        twist_move.angular.y = 0.0
        twist_move.angular.z = average_angle / 15.0

        self.pub.publish(twist_move)

        if abs(twist_move.linear.x) + abs(twist_move.angular.z) < self.immobility_value:
            if self.is_moving : #on bougeais, mais on ne bouge plus
                self.t0 = time.time()
            self.is_moving = False

            diff_time = time.time() - self.t0
            if diff_time > 3.0: #on n'a pas bougé depuis 3s -> fin du follow me
                msg_follow_me_end = String()
                msg_follow_me_end.data = "1"
                self.is_finish = True
                twist_move.linear.x = 0.0
                twist_move.angular.z = 0.0
                self.pub.publish(twist_move)
                self.pub_end.publish(msg_follow_me_end)
        else: #on rebouge
            self.is_moving = True
            self.t0 = time.time()

        # prints results and logger
        self.get_logger().info(f"Filtered ranges : {final_tab} {final_angles}\n ") #Averages : {average_distance} {average_angle}


class PosePublisher(Node):
    def __init__(self):
        super().__init__('pose_publisher')
        
        # Initialisation des variables
        self.last_move_time = time.time()  # Temps du dernier mouvement
        self.idle_time = 3.0  # Seuil d'immobilité de 3 secondes
        self.is_idle = False  # Flag pour savoir si le robot est immobile
        self.timer = self.create_timer(0.1, self.check_idle)  # Vérification toutes les 100 ms
        self.is_finish = False
        self.nav = BasicNavigator()
        
        # Abonnement au topic cmd_vel pour recevoir les commandes de mouvement
        self.create_subscription(Twist, 'cmd_vel', self.cmd_vel_callback, 10)
        
        # Initialisation du pose initiale (valeurs arbitraires pour l'exemple)
        self.init_pose = PoseStamped()
        self.init_pose.pose.position.x = 0.0
        self.init_pose.pose.position.y = 0.0
        self.init_pose.pose.orientation.w = 1.0  # Orientation neutre

        # Publication de la position initiale après 3 secondes d'immobilité
        self.initial_pose_published = False
    
    def cmd_vel_callback(self, msg: Twist):
        """Callback pour vérifier l'immobilité du robot"""
        linear_velocity = msg.linear.x
        angular_velocity = msg.angular.z

        # Si le robot bouge (vitesse linéaire ou angulaire non nulle)
        if linear_velocity != 0.0 or angular_velocity != 0.0:
            self.last_move_time = time.time()  # Mettre à jour le temps du dernier mouvement
            self.is_idle = False  # Le robot n'est pas immobile
        else:
            self.is_idle = True  # Le robot est immobile

    def check_idle(self):
        """Vérifie si le robot est immobile pendant plus de 3 secondes"""
        if self.is_idle and (time.time() - self.last_move_time) >= self.idle_time:
            if not self.initial_pose_published:
                self.send_initial_pose()
                self.initial_pose_published = True
    
    def send_initial_pose(self):
        """Envoie la position initiale au topic 'goal_pose'"""
        self.get_logger().info("Robot immobile depuis 3 secondes, envoi de la position initiale.")
        
        # Envoi de la position initiale au topic 'goal_pose'
        # On utilise le format de message PoseStamped pour cela
        goal_pose = PoseStamped()
        goal_pose.header.stamp.sec = 0
        goal_pose.header.frame_id = 'map'
        goal_pose.pose.position.x = self.init_pose.pose.position.x
        goal_pose.pose.position.y = self.init_pose.pose.position.y
        goal_pose.pose.orientation = self.init_pose.pose.orientation
        
        # Publication du message goal_pose
        self.get_logger().info(f"Position initiale : {goal_pose.pose.position.x}, {goal_pose.pose.position.y}")
        self.nav.goToPose(goal_pose)  # Utilisation de BasicNavigator pour déplacer le robot vers cette position

class Init_pose(Node):
    def __init__(self):
        super().__init__('init_pose')
        self.nav = BasicNavigator()
        qos = QoSProfile(depth=10)
        self.odom_sub = self.create_subscription(
            Odometry,
            'odom',
            self.odom_callback,
            qos)
        # Initialisation du pose initiale (valeurs arbitraires pour l'exemple)

    def odom_callback(self, msg):
        sharedData.init_x = msg.pose.pose.position.x
        sharedData.init_y = msg.pose.pose.position.y
        sharedData.rot_w = msg.pose.orientation
        print(f"{sharedData.init_x}, {sharedData.init_x}, {sharedData.rot_w}")

    def euler_from_quaternion(self, quat):
        """
        Convert quaternion (w in last place) to euler roll, pitch, yaw.

        quat = [x, y, z, w]
        """
        x = quat.x
        y = quat.y
        z = quat.z
        w = quat.w

        sinr_cosp = 2 * (w * x + y * z)
        cosr_cosp = 1 - 2 * (x * x + y * y)
        roll = numpy.arctan2(sinr_cosp, cosr_cosp)

        sinp = 2 * (w * y - z * x)
        pitch = numpy.arcsin(sinp)

        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw = numpy.arctan2(siny_cosp, cosy_cosp)

        return roll, pitch, yaw

def main():
    settings = None
    if os.name != 'nt':
        settings = termios.tcgetattr(sys.stdin)

    rclpy.init()

    #init_robot_pose = Init_pose()
    minimal_subscriber = MinimalSubscriber()
    robot_pose = PosePublisher()

    #Récupérer la pos initial
    #rclpy.spin_once(init_robot_pose)

    print("Follow me has started")
    while minimal_subscriber.is_finish == False:
        rclpy.spin_once(minimal_subscriber)
        time.sleep(0.01)
    print("Follow me is over")

    while robot_pose.is_finish == False:
        rclpy.spin_once(robot_pose)
        print("goto is still going")
        time.sleep(0.01)

    #Goto a position

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_subscriber.destroy_node()
    rclpy.shutdown()
